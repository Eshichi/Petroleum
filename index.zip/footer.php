    <footer class="footer footer-color-black" data-color="black">
        <div class="container">
            <nav class="pull-left">
                <ul>
                    <li>
                        <a href="http://fspetroleum.com/">Products</a>
                    </li>
                    
                    <li>
                        <a href="http://fspetroleum.com/Company.php">The Company</a>
                    </li>
                    <li>
                        <a href="http://fspetroleum.com/Contact.php">Reach Us</a>
                    </li>
                </ul>
            </nav>
            <div class="social-area pull-right">
                <a href="https://www.facebook.com/fs.petroleum" class="btn btn-social btn-facebook btn-simple">
                    <i class="fa fa-facebook-square"></i>
                </a>
                <a href="https://twitter.com/Fspetroleum" class="btn btn-social btn-twitter btn-simple">
                    <i class="fa fa-twitter"></i>
                </a>
                <a href="https://www.instagram.com/fspetroleum/?hl=en" class="btn btn-social btn-pinterest btn-simple">
                    <i class="fa fa-instagram"></i>
                </a>
            </div>
            <div class="copyright">
                 © <script> document.write(new Date().getFullYear()) </script> FS Petroleum, Developed by N.Villanueva
            </div>
        </div>
    </footer>
    
    


</body>

<!--   core js files    -->
<script src="assets/js/jquery.min.js" type="text/javascript"></script>
<script src="assets/js/bootstrap.js" type="text/javascript"></script>

<!--  js library for devices recognition -->
<script type="text/javascript" src="assets/js/modernizr.js"></script>

<!--  script for google maps   -->
<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js"></script>

<!--   file where we handle all the script from the Gaia - Bootstrap Template   -->
<script type="text/javascript" src="assets/js/gaia.js"></script>

</html>