<?php
include 'header.php';
?>



    <div class="section section-header">
        <div class="parallax filter filter-color-red">
            <div class="image"
                style="background-image: url('assets/img/header2.jpg')">
            </div>
            <div class="container" > 
                <div class="content">
                    <div class="title-area">
                        <h1 class="title-modern">Something About Us</h1>
                        <h3>The Company.</h2>
                        <div class="separator line-separator">♦</div>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <div class="section section-our-team-freebie">
        <div class="parallax filter filter-color-black">
            <div class="image" style="background-image:url('assets/img/Refinery.jpg')">
            </div>
            <div class="container">
                <div class="content">
                    <div class="row">
                        <div class="title-area">
                            <h2>COMPANY OVERVIEW</h2>
                            <div class="separator separator-danger">✻</div>
                            <p class="description">FS PETROLEUM PLUS TRADERS INC. was formed in October, 2012 to primarily address
the needs of sophisticated customers for alternative source of high quality lubricants, fuels
and asphalts at very competitive prices. We are essentially dedicated to the manufacture of
lubricants as specified by the customers. We are capable of providing special fuel oil blends
to cater to the client’s requirements. Our company, likewise, provide contract blending, filling
and packaging. We are a flexible company which can easily fit and adjust to the needs of our
customers. <br> <br>
Our company offers you a complete range of lubricants for Automotive, Industrial and Marine
application. We avail of the latest technology from the foremost additive global
manufacturers. In response to our clients need for fuels, we have also expanded to providing
quality fuels such as bunker fuel oils, special fuel oils, as well as automotive and industrial
diesel oil.</p>
                        </div>

                        <div class="title-area">
                            <h2>OUR MISSION</h2>
                            <div class="separator separator-danger">✻</div>
                            <p class="description">We provide work environments where our employees can meet their potential and thrive in
atmosphere of excellence. We strive to be the Industry standard in service to customers. We
maintain a superior level of integrity in interactions with business partners and associates.
We appreciate our achieved success and we conduct our business as model corporate
citizens.</p>
                        </div>
                        <div class="title-area">
                            <h2>QUALITY POLICY</h2>
                            <div class="separator separator-danger">✻</div>
                            <p class="description">To assure that International standards are met, the company invested on the state of the art
laboratory equipment and instrument to carry out rigorous quality control measures.
Likewise, the company is committed to operate under a quality management system to
assure you, our customers, on the consistency and quality of our products and services. We
do more than test our lubricants; we constantly manufacture quality into our products.</p>
                        </div>
                    </div>

                    
                </div>
            </div>
        </div>
    </div>

    <div class="section section-header">
        <div class="parallax filter filter-color-red">
            <div class="image"
                style="background-color:#18426a">
            </div>
            <div class="container" > 
                <div class="content">
                    <div class="title-area">
                        <h1 class="title-modern">Who we are and Clients Testimonials</h1>
                        <h3>Coming Soon.</h2>
                        <div class="separator line-separator">♦</div>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <!-- <div class="section section-our-team-freebie">
        <div class="parallax filter filter-color-black">
            <div class="image" style="background-image:url('assets/img/Rep.jpg')">
            </div>
            <div class="container">
                <div class="content">
                    <div class="row">
                        <div class="title-area">
                            <h2>Who We Are</h2>
                            <div class="separator separator-danger">✻</div>
                            <p class="description">We promise you a new look and more importantly, a new attitude. We build that by getting to know you, your needs and creating the best looking clothes.</p>
                        </div>
                    </div>

                    <div class="team">
                        <div class="row">
                            <div class="col-md-10 col-md-offset-1">
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="card card-member">
                                            <div class="content">
                                                <div class="avatar avatar-danger">
                                                    <img alt="..." class="img-circle" src="assets/img/faces/face_1.jpg"/>
                                                </div>
                                                <div class="description">
                                                    <h3 class="title">name</h3>
                                                    <p class="small-text">CEO / Co-Founder</p>
                                                    <p class="description">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="card card-member">
                                            <div class="content">
                                                <div class="avatar avatar-danger">
                                                    <img alt="..." class="img-circle" src="assets/img/faces/face_4.jpg"/>
                                                </div>
                                                <div class="description">
                                                    <h3 class="title">name</h3>
                                                    <p class="small-text">Product Designer</p>
                                                    <p class="description">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="card card-member">
                                            <div class="content">
                                                <div class="avatar avatar-danger">
                                                    <img alt="..." class="img-circle" src="assets/img/faces/face_3.jpg"/>
                                                </div>
                                                <div class="description">
                                                    <h3 class="title">name</h3>
                                                    <p class="small-text">Marketing Hacker</p>
                                                    <p class="description">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="section section-our-clients-freebie">
        <div class="container">
            <div class="title-area">
                <h5 class="subtitle text-gray">Here are some</h5>
                <h2>Clients Testimonials</h2>
                <div class="separator separator-danger">∎</div>
            </div>

            <ul class="nav nav-text" role="tablist">
                <li class="active">
                    <a href="#testimonial1" role="tab" data-toggle="tab">
                        <div class="image-clients">
                            <img alt="..." class="img-circle" src="assets/img/faces/face_5.jpg"/>
                        </div>
                    </a>
                </li>
                <li>
                    <a href="#testimonial2" role="tab" data-toggle="tab">
                        <div class="image-clients">
                            <img alt="..." class="img-circle" src="assets/img/faces/face_6.jpg"/>
                        </div>
                    </a>
                </li>
                <li>
                    <a href="#testimonial3" role="tab" data-toggle="tab">
                        <div class="image-clients">
                            <img alt="..." class="img-circle" src="assets/img/faces/face_2.jpg"/>
                        </div>
                    </a>
                </li>
            </ul>


            <div class="tab-content">
                <div class="tab-pane active" id="testimonial1">
                    <p class="description"> testing 1
                    Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
                    </p>
                </div>
                <div class="tab-pane" id="testimonial2"> 
                    <p class="description"> testing 2 Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop.</p>
                </div>
                <div class="tab-pane" id="testimonial3"> 
                    <p class="description"> testing 3 Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                </div>

            </div>

        </div>
    </div> -->



<?php
include 'footer.php';
?>