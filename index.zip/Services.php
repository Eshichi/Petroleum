<?php
include 'header.php';
?>

    <div class="section section-header">
        <div class="parallax filter filter-color-red">
            <div class="image"
                style="background-image: url('assets/img/Services.jpg')">
            </div>
            <div class="container" > 
                <div class="content">
                    <div class="title-area">
                        <h1 class="title-modern">Our Services</h1>
                        <div class="separator line-separator">♦</div>
                    </div>
                    <div class="row">
                        <div class="col-md-4"><h3>Toll Blending</h3></div>
                        <div class="col-md-4"><h3>Distribution</h3></div>
                        <div class="col-md-4"><h3>Branding</h3></div>
                    </div>
                    <div class="row">
                        <div class="col-md-4"><h3>Product Formulation</h3></div>
                        <div class="col-md-4"><h3>Storage and Warehousing</h3></div>
                        <div class="col-md-4"><h3>Filling and Packaging</h3></div>
                    </div>
                    <div class="row">
                        <div class="col-md-4"><h3></h3></div>
                        <div class="col-md-4"><h3>Oil Laboratory Testing</h3></div>
                        <div class="col-md-4"><h3></h3></div>
                    </div>
                </div>
               

            </div>
        </div>
    </div>

   


<?php
include 'footer.php';
?>