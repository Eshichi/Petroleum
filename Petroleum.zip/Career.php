<?php
include 'header.php';
?>

    <div class="section section-header">
        <div class="parallax filter filter-color-red">
            <div class="image"
                style="background-color:#18426a">
            </div>
            <div class="container" > 
                <div class="content">
                    <div class="title-area">
                        <h1 class="title-modern">Careers</h1>
                        <h3>Coming Soon.</h2>
                        <div class="separator line-separator">♦</div>
                    </div>
                </div>

            </div>
        </div>
    </div>

   


<?php
include 'footer.php';
?>